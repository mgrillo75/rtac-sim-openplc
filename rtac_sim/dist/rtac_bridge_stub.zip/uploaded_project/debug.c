/*
 * This file is part of OpenPLC Runtime
 *
 * Copyright (C) 2023 Autonomy, GP Orcullo
 * Based on the work by GP Orcullo on Beremiz for uC
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; If not, see <http://www.gnu.org/licenses/>.
 *
 */

#include <stdbool.h>

#include "iec_types_all.h"
#include "POUS.h"

#define SAME_ENDIANNESS      0
#define REVERSE_ENDIANNESS   1

char plc_program_md5[] = "c889f83232ead19f41279b0b8d192530";

uint8_t endianness;


extern MAIN RES0__INSTANCE0;

static const struct {
    void *ptr;
    __IEC_types_enum type;
} debug_vars[] = {
    {&(RES0__INSTANCE0.SIMPLE_BOOL), BOOL_ENUM},
    {&(RES0__INSTANCE0.SIMPLE_BOOL_TRUE), BOOL_ENUM},
    {&(RES0__INSTANCE0.SIMPLE_BYTE), BYTE_ENUM},
    {&(RES0__INSTANCE0.SIMPLE_BYTE_MAX), BYTE_ENUM},
    {&(RES0__INSTANCE0.SIMPLE_INT), INT_ENUM},
    {&(RES0__INSTANCE0.SIMPLE_INT_NEGATIVE), INT_ENUM},
    {&(RES0__INSTANCE0.SIMPLE_INT_MAX), INT_ENUM},
    {&(RES0__INSTANCE0.SIMPLE_INT_MIN), INT_ENUM},
    {&(RES0__INSTANCE0.SIMPLE_DINT), DINT_ENUM},
    {&(RES0__INSTANCE0.SIMPLE_DINT_LARGE), DINT_ENUM},
    {&(RES0__INSTANCE0.SIMPLE_DINT_NEGATIVE), DINT_ENUM},
    {&(RES0__INSTANCE0.SIMPLE_LINT), LINT_ENUM},
    {&(RES0__INSTANCE0.SIMPLE_LINT_LARGE), LINT_ENUM},
    {&(RES0__INSTANCE0.SIMPLE_REAL), REAL_ENUM},
    {&(RES0__INSTANCE0.SIMPLE_REAL_PI), REAL_ENUM},
    {&(RES0__INSTANCE0.SIMPLE_REAL_NEGATIVE), REAL_ENUM},
    {&(RES0__INSTANCE0.SIMPLE_STRING), STRING_ENUM},
    {&(RES0__INSTANCE0.SIMPLE_STRING_HELLO), STRING_ENUM},
    {&(RES0__INSTANCE0.SENSOR1.EN), BOOL_ENUM},
    {&(RES0__INSTANCE0.SENSOR1.ENO), BOOL_ENUM},
    {&(RES0__INSTANCE0.SENSOR1.SENSOR_ID), INT_ENUM},
    {&(RES0__INSTANCE0.SENSOR1.VALUE), REAL_ENUM},
    {&(RES0__INSTANCE0.SENSOR1.IS_VALID), BOOL_ENUM},
    {&(RES0__INSTANCE0.SENSOR1.LOCAL_TEMP), DINT_ENUM},
    {&(RES0__INSTANCE0.SENSOR2.EN), BOOL_ENUM},
    {&(RES0__INSTANCE0.SENSOR2.ENO), BOOL_ENUM},
    {&(RES0__INSTANCE0.SENSOR2.SENSOR_ID), INT_ENUM},
    {&(RES0__INSTANCE0.SENSOR2.VALUE), REAL_ENUM},
    {&(RES0__INSTANCE0.SENSOR2.IS_VALID), BOOL_ENUM},
    {&(RES0__INSTANCE0.SENSOR2.LOCAL_TEMP), DINT_ENUM},
    {&(RES0__INSTANCE0.ROBOT_POSITION.EN), BOOL_ENUM},
    {&(RES0__INSTANCE0.ROBOT_POSITION.ENO), BOOL_ENUM},
    {&(RES0__INSTANCE0.ROBOT_POSITION.X), REAL_ENUM},
    {&(RES0__INSTANCE0.ROBOT_POSITION.Y), REAL_ENUM},
    {&(RES0__INSTANCE0.ROBOT_POSITION.Z), REAL_ENUM},
    {&(RES0__INSTANCE0.ROBOT_POSITION.LOCAL_TEMP), DINT_ENUM},
    {&(RES0__INSTANCE0.TARGET_POSITION.EN), BOOL_ENUM},
    {&(RES0__INSTANCE0.TARGET_POSITION.ENO), BOOL_ENUM},
    {&(RES0__INSTANCE0.TARGET_POSITION.X), REAL_ENUM},
    {&(RES0__INSTANCE0.TARGET_POSITION.Y), REAL_ENUM},
    {&(RES0__INSTANCE0.TARGET_POSITION.Z), REAL_ENUM},
    {&(RES0__INSTANCE0.TARGET_POSITION.LOCAL_TEMP), DINT_ENUM},
    {&(RES0__INSTANCE0.PLC_STATUS.EN), BOOL_ENUM},
    {&(RES0__INSTANCE0.PLC_STATUS.ENO), BOOL_ENUM},
    {&(RES0__INSTANCE0.PLC_STATUS.DEVICE_NAME), STRING_ENUM},
    {&(RES0__INSTANCE0.PLC_STATUS.ERROR_CODE), DINT_ENUM},
    {&(RES0__INSTANCE0.PLC_STATUS.TEMPERATURE), REAL_ENUM},
    {&(RES0__INSTANCE0.PLC_STATUS.IS_ONLINE), BOOL_ENUM},
    {&(RES0__INSTANCE0.PLC_STATUS.UPTIME_SECONDS), LINT_ENUM},
    {&(RES0__INSTANCE0.PLC_STATUS.LOCAL_TEMP), DINT_ENUM},
    {&(RES0__INSTANCE0.BOOL_ARRAY.value.table[0]), BOOL_ENUM},
    {&(RES0__INSTANCE0.BOOL_ARRAY.value.table[1]), BOOL_ENUM},
    {&(RES0__INSTANCE0.BOOL_ARRAY.value.table[2]), BOOL_ENUM},
    {&(RES0__INSTANCE0.BOOL_ARRAY.value.table[3]), BOOL_ENUM},
    {&(RES0__INSTANCE0.BOOL_ARRAY.value.table[4]), BOOL_ENUM},
    {&(RES0__INSTANCE0.BOOL_ARRAY.value.table[5]), BOOL_ENUM},
    {&(RES0__INSTANCE0.BOOL_ARRAY.value.table[6]), BOOL_ENUM},
    {&(RES0__INSTANCE0.BOOL_ARRAY.value.table[7]), BOOL_ENUM},
    {&(RES0__INSTANCE0.INT_ARRAY.value.table[0]), INT_ENUM},
    {&(RES0__INSTANCE0.INT_ARRAY.value.table[1]), INT_ENUM},
    {&(RES0__INSTANCE0.INT_ARRAY.value.table[2]), INT_ENUM},
    {&(RES0__INSTANCE0.INT_ARRAY.value.table[3]), INT_ENUM},
    {&(RES0__INSTANCE0.INT_ARRAY.value.table[4]), INT_ENUM},
    {&(RES0__INSTANCE0.REAL_ARRAY.value.table[0]), REAL_ENUM},
    {&(RES0__INSTANCE0.REAL_ARRAY.value.table[1]), REAL_ENUM},
    {&(RES0__INSTANCE0.REAL_ARRAY.value.table[2]), REAL_ENUM},
    {&(RES0__INSTANCE0.REAL_ARRAY.value.table[3]), REAL_ENUM},
    {&(RES0__INSTANCE0.DINT_ARRAY.value.table[0]), DINT_ENUM},
    {&(RES0__INSTANCE0.DINT_ARRAY.value.table[1]), DINT_ENUM},
    {&(RES0__INSTANCE0.DINT_ARRAY.value.table[2]), DINT_ENUM},
    {&(RES0__INSTANCE0.CYCLE_COUNTER), DINT_ENUM},
    {&(RES0__INSTANCE0.TOGGLE_OUTPUT), BOOL_ENUM},
};

#define VAR_COUNT               72

uint16_t get_var_count(void)
{
    return VAR_COUNT;
}

size_t get_var_size(size_t idx)
{
    if (idx >= VAR_COUNT)
    {
        return 0;
    }
    switch (debug_vars[idx].type) {
    case INT_ENUM:
        return sizeof(INT);
    case BOOL_ENUM:
        return sizeof(BOOL);
    case LINT_ENUM:
        return sizeof(LINT);
    case REAL_ENUM:
        return sizeof(REAL);
    case DINT_ENUM:
        return sizeof(DINT);
    case STRING_ENUM:
        return sizeof(STRING);
    case BYTE_ENUM:
        return sizeof(BYTE);
    default:
        return 0;
    }
}

void *get_var_addr(size_t idx)
{
    void *ptr = debug_vars[idx].ptr;

    switch (debug_vars[idx].type) {
    case INT_ENUM:
        return (void *)&((__IEC_INT_t *) ptr)->value;
    case BOOL_ENUM:
        return (void *)&((__IEC_BOOL_t *) ptr)->value;
    case LINT_ENUM:
        return (void *)&((__IEC_LINT_t *) ptr)->value;
    case REAL_ENUM:
        return (void *)&((__IEC_REAL_t *) ptr)->value;
    case DINT_ENUM:
        return (void *)&((__IEC_DINT_t *) ptr)->value;
    case STRING_ENUM:
        return (void *)&((__IEC_STRING_t *) ptr)->value;
    case BYTE_ENUM:
        return (void *)&((__IEC_BYTE_t *) ptr)->value;
    default:
        return 0;
    }
}

void force_var(size_t idx, bool forced, void *val)
{
    void *ptr = debug_vars[idx].ptr;

    if (forced) {
        size_t var_size = get_var_size(idx);
        switch (debug_vars[idx].type) {
        case INT_ENUM: {
            memcpy(&((__IEC_INT_t *) ptr)->value, val, var_size);
            ((__IEC_INT_t *) ptr)->flags |= __IEC_FORCE_FLAG;
            break;
        }
    
        case BOOL_ENUM: {
            memcpy(&((__IEC_BOOL_t *) ptr)->value, val, var_size);
            ((__IEC_BOOL_t *) ptr)->flags |= __IEC_FORCE_FLAG;
            break;
        }
    
        case LINT_ENUM: {
            memcpy(&((__IEC_LINT_t *) ptr)->value, val, var_size);
            ((__IEC_LINT_t *) ptr)->flags |= __IEC_FORCE_FLAG;
            break;
        }
    
        case REAL_ENUM: {
            memcpy(&((__IEC_REAL_t *) ptr)->value, val, var_size);
            ((__IEC_REAL_t *) ptr)->flags |= __IEC_FORCE_FLAG;
            break;
        }
    
        case DINT_ENUM: {
            memcpy(&((__IEC_DINT_t *) ptr)->value, val, var_size);
            ((__IEC_DINT_t *) ptr)->flags |= __IEC_FORCE_FLAG;
            break;
        }
    
    
        case STRING_ENUM: {
            __IEC_STRING_t *str_ptr = (__IEC_STRING_t *) ptr;
            STRING *str_ptr_data = &str_ptr->value;
            __strlen_t new_len = *((__strlen_t *) val);
            if (new_len > STR_MAX_LEN) {
                new_len = STR_MAX_LEN;
            }
            str_ptr_data->len = new_len;
            strncpy((char *) str_ptr_data->body, ((char *) val) + sizeof(__strlen_t), new_len);
            str_ptr->flags |= __IEC_FORCE_FLAG;
            break;
        }
        case BYTE_ENUM: {
            memcpy(&((__IEC_BYTE_t *) ptr)->value, val, var_size);
            ((__IEC_BYTE_t *) ptr)->flags |= __IEC_FORCE_FLAG;
            break;
        }
    
        default:
            break;
        }
    } else {
        switch (debug_vars[idx].type) {
        case INT_ENUM:
            ((__IEC_INT_t *) ptr)->flags &= ~__IEC_FORCE_FLAG;
            break;
        case BOOL_ENUM:
            ((__IEC_BOOL_t *) ptr)->flags &= ~__IEC_FORCE_FLAG;
            break;
        case LINT_ENUM:
            ((__IEC_LINT_t *) ptr)->flags &= ~__IEC_FORCE_FLAG;
            break;
        case REAL_ENUM:
            ((__IEC_REAL_t *) ptr)->flags &= ~__IEC_FORCE_FLAG;
            break;
        case DINT_ENUM:
            ((__IEC_DINT_t *) ptr)->flags &= ~__IEC_FORCE_FLAG;
            break;
        case STRING_ENUM:
            ((__IEC_STRING_t *) ptr)->flags &= ~__IEC_FORCE_FLAG;
            break;
        case BYTE_ENUM:
            ((__IEC_BYTE_t *) ptr)->flags &= ~__IEC_FORCE_FLAG;
            break;
        default:
            break;
        }
    }
}

void swap_bytes(void *ptr, size_t size)
{
    uint8_t *bytePtr = (uint8_t *)ptr;
    size_t i;
    for (i = 0; i < size / 2; ++i)
    {
        uint8_t temp = bytePtr[i];
        bytePtr[i] = bytePtr[size - 1 - i];
        bytePtr[size - 1 - i] = temp;
    }
}

void trace_reset(void)
{
    for (size_t i=0; i < VAR_COUNT; i++)
    {
        force_var(i, false, 0);
    }
}

void set_trace(size_t idx, bool forced, void *val)
{
    if (idx >= 0 && idx < VAR_COUNT)
    {
        if (endianness == REVERSE_ENDIANNESS)
        {
            // Prevent swapping for STRING type
            if (debug_vars[idx].type == STRING_ENUM)
            {
                // Do nothing
                ;
            }
            else
            {
                swap_bytes(val, get_var_size(idx));
            }
        }

        force_var(idx, forced, val);
    }
}

void set_endianness(uint8_t value)
{
    if (value == SAME_ENDIANNESS || value == REVERSE_ENDIANNESS)
    {
        endianness = value;
    }
}
